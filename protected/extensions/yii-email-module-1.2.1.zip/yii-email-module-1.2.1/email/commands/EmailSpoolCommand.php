<?php
/**
 * EmailSpoolCommand will send emails that are pending in the spool.
 *
 * @author Brett O'Donnell <cornernote@gmail.com>
 * @author Zain Ul abidin <zainengineer@gmail.com>
 * @copyright 2013 Mr PHP
 * @link https://github.com/cornernote/yii-email-module
 * @license BSD-3-Clause https://raw.github.com/cornernote/yii-email-module/master/LICENSE
 *
 * @package yii-email-module
 */
class EmailSpoolCommand extends CConsoleCommand
{

    /**
     * Sends emails
     */
    public function actionIndex()
    {
        // long loop
        set_time_limit(60 * 60 * 24);
        for ($i = 0; $i < 60 * 60; $i++) {
            Yii::app()->emailManager->processSpool();
            sleep(1);
        }
    }

}
