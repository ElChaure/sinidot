<?php
/**
 * Cruge AuthItem messages
 * @author Ricardo Obregón <ricardo@obregon.co>
 * @date 4/12/12 06:05 PM
 */
return array(
    'name' => 'nombre',
);